import 'package:flutter/cupertino.dart';

class AppColors {
  static const Color blue_accent = Color(0xFF448AFF);
}
