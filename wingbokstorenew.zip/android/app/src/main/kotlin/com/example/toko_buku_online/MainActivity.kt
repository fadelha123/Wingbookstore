package com.example.toko_buku_online

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
